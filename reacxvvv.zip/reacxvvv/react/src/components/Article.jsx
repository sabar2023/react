function Article() {
  return <div>ini adalah component pertama</div>;
}

export default Article;
