import { Link } from "react-router-dom";
import { useLoaderData } from "react-router-dom";

function Blog() {
  const posts = useLoaderData();
  return (
    <>
      <h2>my blog post</h2>
      {posts.map((item, index) => {
        <div key={index}>
          <link to={"/blog/${item.id}"}>= {item.title}</link>
        </div>;
      })}
    </>
  );
}

export default Blog;
