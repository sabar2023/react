import React from "react";
import ReactDOM from "react-dom/client";
import data from "./data.js";

import "./index.css";

function App() {
  return (
    <div className="container">
      <Header />
      <Menu />
      <Footer />
    </div>
  );
}

function Header() {
  return <h1>warteg mang udin</h1>;
}

function Menu() {
  const foods = [];
  // const foods = data;
  const numFoods = foods.length;

  return (
    <main className="menu">
      <h2>menu kita</h2>
      {numFoods > 0 ? (
        <ul className="foods">
          {data.map((food) => (
            <Food foodObj={food} key={food.nama} />
          ))}
        </ul>
      ):(
        <p>kosong gan. besok datang lagi</p>
      )
      )}
      
    </main>
  );
}

function Footer() {
  const hour = new Date().getHours();
  const jamBuka = 21;
  const jamTutup = 22;
  const isOpen = hour >= jamBuka && hour <= jamTutup;

  // if (hour < jamBuka || hour > jamTutup) {
  //   alert("warteg mang udin tutup");
  // } else {
  //   alert("warteg mang udin buka");
  // }

  if (isOpen) {

  return <FooterOpenHour jamBuka={jamBuka} jamTutup={jamTutup} />
} else {
  return <FooterClosedHour jamBuka={jamBuka} jamTutup={jamTutup}/>
}
}

function FooterOpenHour(props) {
  return (
    <footer className="footer">
     
        <div className="order">
          <p>
            {new Date().getFullYear()} warung mang udin | jam buka {props.jamBuka}- jam Tutup {props.jamTutup}
          </p>
          <button className="btn">Order</button>
        </div>
      
    </footer>

  )
}

function FooterClosedHour(props) {
  return (
    <footer className="footer">
    <p>maaf gan masih tutup. coba dateng lagi sekitar jam {props.jamBuka}-{props.jamTutup}</p>
    </footer>
  )
}

function Food(props) {
  const { nama, deskripsi, harga, foto, stok } = props.foodObj;
  return (
    <li className="food">
      <img src={.foto} alt={nama} width={100} height={70} />
      <div>
        <h2>{nama}</h2>
        <p>{deskripsi}</p>
        <span>{harga}</span>
      </div>
    </li>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
