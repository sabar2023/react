import React from "react";
import ReactDOM from "react-dom/client";

function App() {
  return (
    <div>
      <Header />
      <Menu />
      <Footer />
    </div>
  );
}

function Header() {
  return <h1>warteg mang udin</h1>;
}

function Menu() {
  return (
    <div>
      <h2>menu kita</h2>
      <Food />
      <Food />
    </div>
  );
}

function Footer() {
  return <Footer>2023 warung mang udin</Footer>;
}

function Food() {
  return (
    <div>
      <img src="food/soto-betawi.jpg" alt="" width={100} height={70} />
      <h2>Soto Betawi</h2>
      <p>soto betawi dari jakarta</p>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
