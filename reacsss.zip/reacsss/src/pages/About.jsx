function About() {
  return <div>ini halaman about</div>;
}

export default About;
